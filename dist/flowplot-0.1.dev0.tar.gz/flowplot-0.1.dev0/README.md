#Flowplot Scripts
Contains classes and functions to plot flows from WinNet.
- plot single flowfiles or snapshots
- average a set of flowfiles and plot integrated flows
- plot a subset of flows leading to or comming from a specific isotope

Examples of usage in Examples.html

This is not very well tested. Use at your own risk.

Author: Max J
